/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author NEHA
 */
public class abc {
    public static void main(String args[]) {
        //char a='2',b='8';
        System.out.println(args[5]);
    }
}
