/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author NEHA
 */
class School { 
    // This is the inner class named Student
    class Student { 
		// This is a method in inner class Student
        public void print() { 
			System.out.println("Hi! I am inner class STUDENT of outer class SCHOOL."); 


} 
    } 
} 
public class inner{ 
    public static void main(String[] args) { 
        // Create an object of inner class Student
                School sc=new School();
	       School.Student student=sc.new Student();

// Access the 'print()' method of the inner class Student using the inner class object
	//School.Student sc=student.new Student();
               int i=8,j=5;
               System.out.println("i+j is"+i+j);
	student.print();
    }
    
}